
        <!-- jQuery 2.0.2 -->
        <script src="<?php echo base_url().'assets/';?>js/jquery.min.js"></script>
        <!-- Bootstrap -->
        <script src="<?php echo base_url().'assets/';?>js/bootstrap.min.js" type="text/javascript"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo base_url().'assets/';?>js/AdminLTE/app.js" type="text/javascript"></script>