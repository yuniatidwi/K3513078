
                    <div class="box box-solid">
                        <div class="box-header">
                            <h3 class="box-title">Hello...</h3>
                        </div><!-- /.box-header -->
                        <div class="box-body">
                          <!--content here-->
                          Selamat datang ...
                          <!--content end-->
                         </div><!-- /.box-body -->
                    </div> 